import React from 'react';

export default class DefaultPage extends React.Component{
     
    render() {
        return (
           <span>default content..</span>
        );
    }


}